# 🏠 Real Estate Management Platform

A comprehensive full-stack real estate management application that connects property managers with potential tenants. Built with modern web technologies and designed for scalability and user experience.

![TypeScript](https://img.shields.io/badge/typescript-%23007ACC.svg?style=for-the-badge&logo=typescript&logoColor=white)
![Next JS](https://img.shields.io/badge/Next-black?style=for-the-badge&logo=next.js&logoColor=white)
![React](https://img.shields.io/badge/react-%2320232a.svg?style=for-the-badge&logo=react&logoColor=%2361DAFB)
![TailwindCSS](https://img.shields.io/badge/tailwindcss-%2338B2AC.svg?style=for-the-badge&logo=tailwind-css&logoColor=white)
![NodeJS](https://img.shields.io/badge/node.js-6DA55F?style=for-the-badge&logo=node.js&logoColor=white)
![Express.js](https://img.shields.io/badge/express.js-%23404d59.svg?style=for-the-badge&logo=express&logoColor=%2361DAFB)
![Prisma](https://img.shields.io/badge/Prisma-3982CE?style=for-the-badge&logo=Prisma&logoColor=white)
![PostgreSQL](https://img.shields.io/badge/postgresql-%23316192.svg?style=for-the-badge&logo=postgresql&logoColor=white)
![AWS](https://img.shields.io/badge/AWS-%23FF9900.svg?style=for-the-badge&logo=amazon-aws&logoColor=white)

## 📋 Table of Contents

- [Features](#features)
- [Tech Stack](#tech-stack)
- [Architecture](#architecture)
- [Getting Started](#getting-started)
- [Installation](#installation)
- [Configuration](#configuration)
- [Usage](#usage)
- [API Documentation](#api-documentation)
- [Database Schema](#database-schema)

## ✨ Features

### 👥 Multi-Role System

- **Property Managers**: Create and manage properties, review applications, track leases
- **Tenants**: Search properties, submit applications, manage favorites, track residencies

### 🏘️ Property Management

- **CRUD Operations**: Create, read, update, delete properties
- **Image Upload**: Support for multiple property images with AWS S3 integration
- **Advanced Search**: Filter by location, price, amenities, property type, square footage
- **Geographic Search**: Coordinate-based property discovery with Mapbox integration
- **Property Details**: Comprehensive property information with highlights and amenities

### 📋 Application System

- **Application Submission**: Tenants can apply for properties
- **Application Review**: Managers can approve/reject applications
- **Status Tracking**: Real-time application status updates
- **Automated Lease Creation**: Approved applications automatically create lease agreements

### 💰 Lease & Payment Management

- **Lease Tracking**: Monitor active leases and rental agreements
- **Payment History**: Track rent payments and financial records
- **Payment Reminders**: Automated payment notification system

### 🔍 Advanced Features

- **Favorites System**: Save and organize preferred properties
- **Real-time Notifications**: Toast notifications for user actions
- **Responsive Design**: Responsive UI
- **Search & Filters**: Advanced property filtering and search capabilities

## 🛠️ Tech Stack

### Frontend

- **Framework**: Next.js 15.3.2 with App Router
- **Language**: TypeScript
- **Styling**: Tailwind CSS with shadcn/ui components
- **State Management**: Redux Toolkit Query (RTK Query)
- **Authentication**: AWS Amplify with Cognito
- **Maps**: Mapbox GL JS
- **UI Components**: Radix UI primitives
- **Animations**: Framer Motion
- **File Uploads**: FilePond with image preview

### Backend

- **Runtime**: Node.js with Express.js 5.1.0
- **Language**: TypeScript
- **Database**: PostgreSQL with PostGIS extension
- **ORM**: Prisma 6.10.1
- **Authentication**: JWT with AWS Cognito integration
- **File Storage**: AWS S3
- **Validation**: Zod schemas
- **Rate Limiting**: Express rate limit
- **Security**: Helmet.js, CORS

### DevOps & Tools

- **Database Migrations**: Prisma Migrate
- **API Documentation**: RESTful API design
- **Environment Management**: dotenv
- **Code Quality**: ESLint, TypeScript strict mode
- **Build Tools**: Next.js build system, TypeScript compiler

## 🏗️ Architecture

```
real-estate-app/
├── client/                    # Next.js frontend application
│   ├── src/
│   │   ├── app/              # App router pages and layouts
│   │   ├── components/       # Reusable UI components
│   │   ├── hooks/           # Custom React hooks
│   │   ├── lib/             # Utility functions and configurations
│   │   ├── state/           # Redux store and API definitions
│   │   └── types/           # TypeScript type definitions
│   └── public/              # Static assets
│
├── server/                   # Express.js backend application
│   ├── src/
│   │   ├── controllers/     # Request handlers
│   │   ├── middleware/      # Express middleware
│   │   ├── routes/          # API route definitions
│   │   ├── services/        # Business logic layer
│   │   ├── types/           # TypeScript interfaces
│   │   ├── utils/           # Helper functions
│   │   └── validators/      # Input validation schemas
│   └── prisma/              # Database schema and migrations
│
└── asset-download/          # Additional assets and utilities
```

## 🚀 Getting Started

### Prerequisites

- **Node.js**: v18.0.0 or higher
- **npm**: v8.0.0 or higher
- **PostgreSQL**: v14.0 or higher with PostGIS extension
- **AWS Account**: For Cognito authentication and S3 storage

### Installation

1. **Clone the repository**

   ```bash
   git clone https://github.com/yourusername/real-estate-app.git
   cd real-estate-app
   ```

2. **Install client dependencies**

   ```bash
   cd client
   npm install
   ```

3. **Install server dependencies**

   ```bash
   cd ../server
   npm install
   ```

4. **Set up the database**

   ```bash
   # Generate Prisma client
   npx prisma generate

   # Run database migrations
   npx prisma migrate dev

   # Seed the database (optional)
   npm run seed
   ```

## ⚙️ Configuration

### Client Environment Variables (.env.local)

```bash
NEXT_PUBLIC_API_BASE_URL=http://localhost:8000/api
NEXT_PUBLIC_AWS_REGION=your-aws-region
NEXT_PUBLIC_COGNITO_USER_POOL_ID=your-cognito-user-pool-id
NEXT_PUBLIC_COGNITO_USER_POOL_CLIENT_ID=your-cognito-client-id
NEXT_PUBLIC_MAPBOX_ACCESS_TOKEN=your-mapbox-token
```

### Server Environment Variables (.env)

```bash
DATABASE_URL=postgresql://username:password@localhost:5432/realestatedb
JWT_SECRET=your-jwt-secret
AWS_REGION=your-aws-region
AWS_COGNITO_USER_POOL_ID=your-cognito-user-pool-id
AWS_ACCESS_KEY_ID=your-aws-access-key
AWS_SECRET_ACCESS_KEY=your-aws-secret-key
S3_BUCKET_NAME=your-s3-bucket-name
PORT=8000
```

### AWS Services Setup

1. **Cognito User Pool**

   - Create a Cognito User Pool for authentication
   - Configure custom attributes for user roles
   - Set up app client with appropriate OAuth settings

2. **S3 Bucket**
   - Create an S3 bucket for property image storage
   - Configure appropriate IAM permissions
   - Enable CORS for web access

## 💻 Usage

### Development

1. **Start the backend server**

   ```bash
   cd server
   npm run dev
   ```

   Server will run on `http://localhost:8000`

2. **Start the frontend application**
   ```bash
   cd client
   npm run dev
   ```
   Application will run on `http://localhost:3000`

### Production

1. **Build and start the backend**

   ```bash
   cd server
   npm run start
   ```

2. **Build and start the frontend**
   ```bash
   cd client
   npm run build
   npm start
   ```

## 📚 API Documentation

### Authentication

All API endpoints require JWT authentication except for public property listings.

### Core Endpoints

#### Properties

- `GET /api/properties` - Get properties with filters
- `GET /api/properties/:id` - Get property details
- `POST /api/properties` - Create new property (Manager only)
- `PUT /api/properties/:id` - Update property (Manager only)

#### Applications

- `GET /api/applications` - Get applications
- `POST /api/applications` - Submit new application
- `PUT /api/applications/:id/status` - Update application status

#### Users

- `GET /api/tenants/:cognitoId` - Get tenant profile
- `PUT /api/tenants/:cognitoId` - Update tenant profile
- `GET /api/managers/:cognitoId` - Get manager profile
- `PUT /api/managers/:cognitoId` - Update manager profile

#### Leases

- `GET /api/leases` - Get leases
- `GET /api/properties/leases/:propertyId` - Get property leases
- `GET /api/leases/:id/payments` - Get lease payments

## 🗄️ Database Schema

The application uses PostgreSQL with the following main entities:

- **Users**: Tenants and Managers with AWS Cognito integration
- **Properties**: Real estate listings with geographic data
- **Applications**: Tenant applications for properties
- **Leases**: Rental agreements between managers and tenants
- **Payments**: Rent payment tracking
- **Locations**: Geographic location data with PostGIS

## 🙏 Acknowledgments

- [Next.js](https://nextjs.org/) for the amazing React framework
- [Prisma](https://www.prisma.io/) for the excellent database toolkit
- [Tailwind CSS](https://tailwindcss.com/) for the utility-first CSS framework
- [shadcn/ui](https://ui.shadcn.com/) for the beautiful component library
- [AWS Amplify](https://aws.amazon.com/amplify/) for authentication and hosting
- [Mapbox](https://www.mapbox.com/) for mapping services

---
