import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";

declare global {
  namespace Express {
    interface Request {
      user?: {
        id: string;
        role: string;
      };
    }
  }
}

const JWT_SECRET = process.env.JWT_SECRET!;

if (!JWT_SECRET) {
  throw new Error("Missing required JWT_SECRET environment variable");
}

export const authMiddleware = (allowedRoles: string[]) => {
  return (req: Request, res: Response, next: NextFunction): void => {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      res.status(401).json({ message: "Authorization header required" });
      return;
    }

    const token = authHeader.split(" ")[1];

    try {
      const decoded = jwt.verify(token, JWT_SECRET) as {
        sub: string;
        role: string;
        email: string;
      };

      const userRole = decoded.role.toLowerCase();

      if (!allowedRoles.map((r) => r.toLowerCase()).includes(userRole)) {
        res.status(403).json({ message: "Access Denied" });
        return;
      }

      req.user = { id: decoded.sub, role: userRole };
      next();
    } catch (error: any) {
      if (error.name === "TokenExpiredError") {
        res.status(401).json({ message: "Token has expired" });
        return;
      }
      res.status(401).json({ message: "Invalid token" });
    }
  };
};
