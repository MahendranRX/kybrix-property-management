// src/middleware/validationMiddleware.ts
import { Request, Response, NextFunction } from "express";
import { z, ZodError } from "zod";
import { AppError } from "./errorHandler";
import {
  cognitoIdParamSchema,
  uniqueIdSchema,
} from "../validators/commonValidators";

/**
 * Creates a middleware function to validate request body data against a Zod schema
 * @param {z.ZodObject<any, any>} schema - Zod schema to validate against
 * @returns {Function} Express middleware function for data validation
 * @throws {400} When request body is empty or fails validation
 * @throws {500} When unexpected validation error occurs
 * @since 1.0.0
 *
 * @example
 * // Validate user creation data
 * router.post('/users', validateData(createUserSchema), createUserHandler);
 */
export function validateData(schema: z.ZodObject<any, any>) {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      if (Object.keys(req.body).length === 0) {
        throw new AppError("Request body cannot be empty", 400);
      }
      schema.parse(req.body);
      next();
    } catch (error) {
      if (error instanceof ZodError) {
        const errorMessages = error.issues.map(
          (issue: any) => `${issue.path.join(".")} is ${issue.message}`
        );
        throw new AppError(`Invalid data: ${errorMessages.join(", ")}`, 400);
      } else if (error instanceof AppError) {
        throw error; // Re-throwing AppError as-is
      } else {
        console.log("Validating request body:", req.body);
        console.error("Unexpected validation error:", error);
        throw new AppError("Internal Server Error", 500);
      }
    }
  };
}

/**
 * Creates a middleware function to validate query parameters against a Zod schema
 * Used for validating filter parameters, search queries, and other URL query parameters
 * @param {z.ZodObject<any, any>} schema - Zod schema to validate against
 * @returns {Function} Express middleware function for query parameter validation
 * @throws {400} When query parameters fail validation
 * @throws {500} When unexpected validation error occurs
 * @since 1.0.0
 *
 * @example
 * // Validate property filter parameters
 * router.get('/properties', validateQuery(propertyFilterSchema), getPropertiesHandler);
 */
export function validateQuery(schema: z.ZodObject<any, any>) {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      schema.parse(req.query);
      next();
    } catch (error) {
      if (error instanceof ZodError) {
        const errorMessages = error.issues.map(
          (issue: any) => `${issue.path.join(".")} is ${issue.message}`
        );
        throw new AppError(
          `Invalid query parameters: ${errorMessages.join(", ")}`,
          400
        );
      } else if (error instanceof AppError) {
        throw error; // Re-throwing AppError as-is
      } else {
        console.error("Unexpected query validation error:", error);
        throw new AppError("Internal Server Error", 500);
      }
    }
  };
}

/**
 * Express middleware to validate Cognito ID parameter in request URLs
 * Validates the cognitoId parameter against the UUID format
 * @param {Request} req - Express request object
 * @param {Response} res - Express response object
 * @param {NextFunction} next - Express next function
 * @throws {AppError} 400 when Cognito ID format is invalid
 * @since 1.0.0
 *
 * @example
 * // Use as route middleware
 * router.get('/users/:cognitoId', validateCognitoIdParam, getUserHandler);
 */
export const validateCognitoIdParam = (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const paramToValidate = { cognitoId: req.params.cognitoId };
  console.log("Param to validate cognito id:", paramToValidate);
  const result = cognitoIdParamSchema.safeParse(paramToValidate);
  if (!result.success) {
    throw new AppError("Invalid ID", 400);
  }
  next();
};

/**
 * Express middleware to validate unique ID parameter in request URLs
 * Validates the uniqueId parameter and ensures it's a positive integer
 * @param {Request} req - Express request object
 * @param {Response} res - Express response object
 * @param {NextFunction} next - Express next function
 * @throws {AppError} 400 when unique ID format is invalid
 * @since 1.0.0
 *
 * @example
 * // Use as route middleware
 * router.get('/properties/:propertyId', validateUniqueIdParam, getPropertyHandler);
 */
export const validateUniqueIdParam = (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    let paramToValidate;

    console.log("Request params:", req.params.propertyId);
    if (req.params.leaseId) {
      paramToValidate = { id: req.params.leaseId };
    } else if (req.params.propertyId) {
      paramToValidate = { id: req.params.propertyId };
    } else if (req.params.applicationId) {
      paramToValidate = { id: req.params.applicationId };
    }
    if (!paramToValidate) {
      throw new AppError("ID parameter is required", 400);
    }
    const result = uniqueIdSchema.safeParse(paramToValidate);
    if (!result.success) {
      throw new AppError("Invalid ID", 400);
    }
    next();
  } catch (error) {
    if (error instanceof ZodError) {
      const errorMessage = error.issues[0]?.message || "Invalid Unique ID";
      throw new AppError(errorMessage, 400);
    }
    throw new AppError("Invalid Unique ID format", 400);
  }
};
