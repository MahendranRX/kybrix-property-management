import { Request, Response, NextFunction } from "express";

/**
 * Custom error class for application-specific errors
 * Extends the native Error class with HTTP status codes
 * @class AppError
 * @extends {Error}
 * @since 1.0.0
 */
export class AppError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

/**
 * Global error handler middleware for Express applications
 * Handles all errors and sends appropriate HTTP responses
 * @param {any} err - The error object (can be AppError or any other error)
 * @param {Request} req - Express request object
 * @param {Response} res - Express response object
 * @param {NextFunction} next - Express next function
 * @since 1.0.0
 */
export function errorHandler(
  err: any,
  req: Request,
  res: Response,
  next: NextFunction
) {
  const status = err.status || 500;
  const message = err.message || "Internal Server Error";

  console.log("Error Handler Middleware Invoked");
  console.log("err", err);
  console.error("err", err);

  res.status(status).json({
    success: false,
    error: message,
    ...(process.env.NODE_ENV === "development" && { stack: err.stack }),
  });
}
