import { PrismaClient, Prisma, Location } from "@prisma/client";
import { AppError } from "../middleware/errorHandler";
import { wktToGeoJSON } from "@terraformer/wkt";
import { S3Client } from "@aws-sdk/client-s3";
import { Upload } from "@aws-sdk/lib-storage";
import axios from "axios";
const prisma = new PrismaClient();

const s3Client = new S3Client({
  region: process.env.AWS_REGION,
});

/**
 * Service function to retrieve properties based on filters
 * @param {any} query - Query parameters from request
 * @returns {Promise<any[]>} Array of properties
 * @throws {AppError} 500 when query fails
 */
export const getProperties = async (query: any): Promise<any[]> => {
  try {
    const {
      favoriteIds,
      priceMin,
      priceMax,
      beds,
      baths,
      propertyType,
      squareFeetMin,
      squareFeetMax,
      amenities,
      availableFrom,
      latitude,
      longitude,
    } = query;

    let whereConditions: Prisma.Sql[] = [];

    if (favoriteIds) {
      const favoriteIdsArray = (favoriteIds as string).split(",").map(Number);
      whereConditions.push(
        Prisma.sql`p.id IN (${Prisma.join(favoriteIdsArray)})`
      );
    }

    if (priceMin) {
      whereConditions.push(
        Prisma.sql`p."pricePerMonth" >= ${Number(priceMin)}`
      );
    }

    if (priceMax) {
      whereConditions.push(
        Prisma.sql`p."pricePerMonth" <= ${Number(priceMax)}`
      );
    }

    if (beds && beds !== "any") {
      whereConditions.push(Prisma.sql`p.beds >= ${Number(beds)}`);
    }

    if (baths && baths !== "any") {
      whereConditions.push(Prisma.sql`p.baths >= ${Number(baths)}`);
    }

    if (squareFeetMin) {
      whereConditions.push(
        Prisma.sql`p."squareFeet" >= ${Number(squareFeetMin)}`
      );
    }

    if (squareFeetMax) {
      whereConditions.push(
        Prisma.sql`p."squareFeet" <= ${Number(squareFeetMax)}`
      );
    }

    if (propertyType && propertyType !== "any") {
      whereConditions.push(
        Prisma.sql`p."propertyType" = ${propertyType}::"PropertyType"`
      );
    }

    if (amenities && amenities !== "any") {
      const amenitiesArray = (amenities as string).split(",");
      whereConditions.push(Prisma.sql`p.amenities @> ${amenitiesArray}`);
    }

    if (availableFrom && availableFrom !== "any") {
      const availableFromDate =
        typeof availableFrom === "string" ? availableFrom : null;
      if (availableFromDate) {
        const date = new Date(availableFromDate);
        if (!isNaN(date.getTime())) {
          whereConditions.push(
            Prisma.sql`NOT EXISTS (
              SELECT 1 FROM "Lease" l 
              WHERE l."propertyId" = p.id 
              AND l."endDate" > ${date.toISOString()}
            )`
          );
        }
      }
    }

    if (latitude && longitude) {
      const lat = parseFloat(latitude as string);
      const lng = parseFloat(longitude as string);
      const radiusInKilometers = 50; // 50km radius

      // Use ST_DWithin with geography type for more accurate distance calculation
      whereConditions.push(
        Prisma.sql`ST_DWithin(
          l.coordinates::geography,
          ST_SetSRID(ST_MakePoint(${lng}, ${lat}), 4326)::geography,
          ${radiusInKilometers * 1000}
        )`
      );
    }

    const completeQuery = Prisma.sql`
      SELECT 
        p.*,
        json_build_object(
          'id', l.id,
          'address', l.address,
          'city', l.city,
          'state', l.state,
          'country', l.country,
          'postalCode', l."postalCode",
          'coordinates', json_build_object(
            'longitude', ST_X(l."coordinates"::geometry),
            'latitude', ST_Y(l."coordinates"::geometry)
          )
        ) as location
      FROM "Property" p
      JOIN "Location" l ON p."locationId" = l.id
      ${
        whereConditions.length > 0
          ? Prisma.sql`WHERE ${Prisma.join(whereConditions, " AND ")}`
          : Prisma.empty
      }
    `;

    return await prisma.$queryRaw(completeQuery);
  } catch (error: any) {
    throw new AppError(`Failed to get properties: ${error.message}`, 500);
  }
};

/**
 * Service function to find a property by ID
 * @param {number} id - Property ID
 * @returns {Promise<any>} Property with location
 * @throws {AppError} 500 when query fails
 */
export const findPropertyById = async (id: number): Promise<any> => {
  try {
    return await prisma.property.findUnique({
      where: { id },
      include: {
        location: true,
      },
    });
  } catch (error: any) {
    throw new AppError(`Failed to find property: ${error.message}`, 500);
  }
};

export const getPropertyPriceAndDeposit = async (
  id: number
): Promise<{ pricePerMonth: number; securityDeposit: number } | null> => {
  try {
    return await prisma.property.findUnique({
      where: { id },
      select: {
        pricePerMonth: true,
        securityDeposit: true,
      },
    });
  } catch (error: any) {
    throw new AppError(`Failed to find property: ${error.message}`, 500);
  }
};

/**
 * Service function to get property with coordinates
 * @param {any} property - Property object with location
 * @returns {Promise<any>} Property with transformed coordinates
 * @throws {AppError} 500 when coordinate transformation fails
 */
export const getPropertyWithCoordinates = async (
  property: any
): Promise<any> => {
  try {
    const coordinates: { coordinates: string }[] =
      await prisma.$queryRaw`SELECT ST_asText(coordinates) as coordinates from "Location" where id = ${property.location.id}`;

    const geoJSON: any = wktToGeoJSON(coordinates[0]?.coordinates || "");
    const longitude = geoJSON.coordinates[0];
    const latitude = geoJSON.coordinates[1];

    return {
      ...property,
      location: {
        ...property.location,
        coordinates: {
          longitude,
          latitude,
        },
      },
    };
  } catch (error: any) {
    throw new AppError(
      `Failed to get property with coordinates: ${error.message}`,
      500
    );
  }
};

/**
 * Service function to upload photos to S3 and get URLs
 * @param {Express.Multer.File[]} files - Array of uploaded files
 * @returns {Promise<string[]>} Array of S3 URLs
 * @throws {AppError} 500 when upload fails
 */
export const getPhotoUrls = async (
  files: Express.Multer.File[]
): Promise<string[]> => {
  try {
    return await Promise.all(
      files.map(async (file) => {
        const uploadParams = {
          Bucket: process.env.S3_BUCKET_NAME!,
          Key: `properties/${Date.now()}-${file.originalname}`,
          Body: file.buffer,
          ContentType: file.mimetype,
        };

        const uploadResult = await new Upload({
          client: s3Client,
          params: uploadParams,
        }).done();

        return uploadResult.Location || "";
      })
    );
  } catch (error: any) {
    throw new AppError(`Failed to upload photos: ${error.message}`, 500);
  }
};

/**
 * Service function to create a location with geocoding
 * @param {object} locationData - Location data with address, city, state, country, postalCode
 * @returns {Promise<Location>} Created location with coordinates
 * @throws {AppError} 500 when geocoding or location creation fails
 */
export const createLocation = async (locationData: {
  address: string;
  city: string;
  state: string;
  country: string;
  postalCode: string;
}): Promise<Location> => {
  try {
    const { address, city, state, country, postalCode } = locationData;

    const geocodingUrl = `https://nominatim.openstreetmap.org/search?${new URLSearchParams(
      {
        street: address,
        city,
        country,
        postalcode: postalCode,
        format: "json",
        limit: "1",
      }
    ).toString()}`;

    const geocodingResponse = await axios.get(geocodingUrl, {
      headers: {
        "User-Agent": "RealEstateApp (justsomedummyemail@gmail.com",
      },
    });

    const [longitude, latitude] =
      geocodingResponse.data[0]?.lon && geocodingResponse.data[0]?.lat
        ? [
            parseFloat(geocodingResponse.data[0]?.lon),
            parseFloat(geocodingResponse.data[0]?.lat),
          ]
        : [0, 0];

    // create location
    const [location] = await prisma.$queryRaw<Location[]>`
      INSERT INTO "Location" (address, city, state, country, "postalCode", coordinates)
      VALUES (${address}, ${city}, ${state}, ${country}, ${postalCode}, ST_SetSRID(ST_MakePoint(${longitude}, ${latitude}), 4326))
      RETURNING id, address, city, state, country, "postalCode", ST_AsText(coordinates) as coordinates;
    `;

    return location;
  } catch (error: any) {
    throw new AppError(`Failed to create location: ${error.message}`, 500);
  }
};

/**
 * Service function to create a property
 * @param {any} propertyData - Property data from request body
 * @param {string[]} photoUrls - Array of photo URLs
 * @param {number} locationId - Location ID
 * @param {string} managerCognitoId - Manager Cognito ID
 * @returns {Promise<any>} Created property with location and manager
 * @throws {AppError} 500 when property creation fails
 */
export const createProperty = async (
  propertyData: any,
  // photoUrls: string[],
  locationId: number,
  managerCognitoId: string
): Promise<any> => {
  try {
    return await prisma.property.create({
      data: {
        ...propertyData,
        // photoUrls,
        locationId,
        managerCognitoId,
        amenities:
          typeof propertyData.amenities === "string"
            ? propertyData.amenities.split(",")
            : [],
        highlights:
          typeof propertyData.highlights === "string"
            ? propertyData.highlights.split(",")
            : [],
        isPetsAllowed: propertyData.isPetsAllowed === "true",
        isParkingIncluded: propertyData.isParkingIncluded === "true",
        pricePerMonth: parseFloat(propertyData.pricePerMonth),
        securityDeposit: parseFloat(propertyData.securityDeposit),
        applicationFee: parseFloat(propertyData.applicationFee),
        beds: parseInt(propertyData.beds),
        baths: parseFloat(propertyData.baths),
        squareFeet: parseInt(propertyData.squareFeet),
      },
      include: {
        location: true,
        manager: true,
      },
    });
  } catch (error: any) {
    throw new AppError(`Failed to create property: ${error.message}`, 500);
  }
};
