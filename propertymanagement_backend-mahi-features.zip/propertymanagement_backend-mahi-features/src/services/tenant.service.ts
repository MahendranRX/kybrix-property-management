import { PrismaClient, Prisma } from "@prisma/client";
import { UpdateTenantData, CreateTenantData } from "../types/tenant.types";
import { wktToGeoJSON } from "@terraformer/wkt";

const prisma = new PrismaClient();

/**
 * Finds a tenant by their Cognito ID
 * @param {string} cognitoId - The Cognito ID of the tenant
 * @param {Prisma.TenantInclude} include - Optional include object for relations
 * @returns {Promise<Tenant | null>} The tenant object or null if not found
 * @since 1.0.0
 */
export const findTenantById = (cognitoId: string) => {
  return prisma.tenant.findUnique({ where: { cognitoId } });
};

/**
 * Finds a tenant by their Cognito ID with favorites included
 * @param {string} cognitoId - The Cognito ID of the tenant
 * @returns {Promise<Tenant & {favorites: Property[]} | null>} The tenant object with favorites or null if not found
 * @since 1.0.0
 */
export const findTenantWithFavorites = (cognitoId: string) => {
  return prisma.tenant.findUnique({
    where: { cognitoId },
    include: { favorites: true },
  });
};

/**
 * Adds a property to tenant's favorites
 * @param {string} cognitoId - The Cognito ID of the tenant
 * @param {number} propertyId - The property ID to add to favorites
 * @returns {Promise<Tenant & {favorites: Property[]}>} The updated tenant with favorites
 * @since 1.0.0
 */
export const addFavoriteProperty = (cognitoId: string, propertyId: number) => {
  return prisma.tenant.update({
    where: { cognitoId },
    data: {
      favorites: {
        connect: { id: propertyId },
      },
    },
    include: { favorites: true },
  });
};

export const removeFavoriteProperty = (
  cognitoId: string,
  propertyId: number
) => {
  return prisma.tenant.update({
    where: { cognitoId },
    data: {
      favorites: {
        disconnect: { id: propertyId },
      },
    },
    include: { favorites: true },
  });
};

/**
 * Updates a tenant's information by their Cognito ID
 * @param {string} cognitoId - The Cognito ID of the tenant to update
 * @param {UpdateTenantData} data - The data to update
 * @returns {Promise<Tenant>} The updated tenant object
 * @throws {Error} When tenant is not found or update fails
 * @since 1.0.0
 */
export const updateTenantById = (
  cognitoId: string,
  data: UpdateTenantData,
  include?: Prisma.TenantInclude
) => {
  return prisma.tenant.update({
    where: { cognitoId },
    data,
    include,
  });
};

/**
 * Creates a new tenant in the database
 * @param {CreateTenantData} data - The tenant data to create
 * @returns {Promise<Tenant>} The created tenant object
 * @throws {Error} When creation fails or unique constraint is violated
 * @since 1.0.0
 */
export const createTenant = (data: CreateTenantData) => {
  return prisma.tenant.create({ data });
};

export const getCurrentResidences = async (cognitoId: string) => {
  const residences = await prisma.property.findMany({
    where: { tenants: { some: { cognitoId } } },
    include: {
      location: true,
    },
  });

  const residencesWithFormattedLocation = await Promise.all(
    residences.map(async (property) => {
      const coordinates: { coordinates: string }[] =
        await prisma.$queryRaw`SELECT ST_asText(coordinates) as coordinates from "Location" where id = ${property.location.id}`;

      const geoJSON: any = wktToGeoJSON(coordinates[0]?.coordinates || "");
      const longitude = geoJSON.coordinates[0];
      const latitude = geoJSON.coordinates[1];

      return {
        ...property,
        location: {
          ...property.location,
          coordinates: {
            longitude,
            latitude,
          },
        },
      };
    })
  );

  return residencesWithFormattedLocation;
};
