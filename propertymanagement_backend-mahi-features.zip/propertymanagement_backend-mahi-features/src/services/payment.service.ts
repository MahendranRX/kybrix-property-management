import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export const getPaymentsByLeaseId = (id: string) => {
  return prisma.payment.findMany({ where: { leaseId: Number(id) } });
};
