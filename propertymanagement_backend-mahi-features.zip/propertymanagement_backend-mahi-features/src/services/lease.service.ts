import { PrismaClient, Lease, Tenant, Property } from "@prisma/client";
import { AppError } from "../middleware/errorHandler";

const prisma = new PrismaClient();

export const getLeases = async (): Promise<
  (Lease & { tenant: Tenant; property: Property })[]
> => {
  try {
    const leases = await prisma.lease.findMany({
      include: {
        tenant: true,
        property: true,
      },
    });
    return leases;
  } catch (error: any) {
    throw new AppError(`Error retrieving leases: ${error.message}`, 500);
  }
};

export const findLeaseById = (id: string) => {
  return prisma.lease.findUnique({ where: { id: Number(id) } });
};

export const getLeasesByPropertyId = async (
  propertyId: number
): Promise<(Lease & { tenant: Tenant; property: Property })[]> => {
  try {
    const leases = await prisma.lease.findMany({
      where: { propertyId },
      include: {
        tenant: true,
        property: true,
      },
    });
    return leases;
  } catch (error: any) {
    throw new AppError(`Error retrieving leases: ${error.message}`, 500);
  }
};
