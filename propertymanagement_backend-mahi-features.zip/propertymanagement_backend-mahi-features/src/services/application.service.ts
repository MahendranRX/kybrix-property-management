import {
  Prisma,
  PrismaClient,
  ApplicationStatus,
  Application,
  Property,
  Tenant,
  Lease,
} from "@prisma/client";
import { calculateNextPaymentDate } from "../utils/applications/applicationUtils";
import { property } from "zod";
import { AppError } from "../middleware/errorHandler";

const prisma = new PrismaClient();

export const determineWhereClause = (
  userId: string,
  userType: string
):
  | { tenantCognitoId?: string; property?: { managerCognitoId: string } }
  | undefined => {
  if (userId && userType) {
    if (userType === "tenant") {
      return { tenantCognitoId: String(userId) };
    } else if (userType === "manager") {
      return {
        property: {
          managerCognitoId: String(userId),
        },
      };
    }
  }
};

export const findApplications = async (
  whereClause:
    | { tenantCognitoId?: string; property?: { managerCognitoId: string } }
    | undefined
) => {
  return await prisma.application.findMany({
    where: whereClause,
    include: {
      property: {
        include: {
          location: true,
          manager: true,
        },
      },
      tenant: true,
    },
  });
};

export const findApplicationById = async (
  id: string
): Promise<
  | (Application & { property: Property; tenant: Tenant; lease: Lease | null })
  | null
> => {
  try {
    return await prisma.application.findUnique({
      where: { id: Number(id) },
      include: {
        property: true,
        tenant: true,
        lease: true,
      },
    });
  } catch (error: any) {
    throw new AppError(`Failed to find application: ${error.message}`, 500);
  }
};

export const formatApplications = async (
  applications: Awaited<ReturnType<typeof findApplications>>
) => {
  return await Promise.all(
    applications.map(async (app) => {
      const lease = await prisma.lease.findFirst({
        where: {
          tenant: {
            cognitoId: app.tenantCognitoId,
          },
          propertyId: app.propertyId,
        },
        orderBy: { startDate: "desc" },
      });

      return {
        ...app,
        property: {
          ...app.property,
          address: app.property.location.address,
        },
        manager: app.property.manager,
        lease: lease
          ? {
              ...lease,
              nextPaymentDate: calculateNextPaymentDate(lease.startDate),
            }
          : null,
      };
    })
  );
};

/**
 * Creates a new application with lease in a transaction
 * @param {ApplicationData} applicationData - Application data from request
 * @param {PropertyData} property - Property data with pricePerMonth and securityDeposit
 * @returns {Promise<ApplicationWithRelations>} Created application with related data
 * @throws {Error} When transaction fails
 * @since 1.0.0
 */
export const createApplicationWithLease = async (
  applicationData: {
    applicationDate: string;
    status: ApplicationStatus;
    propertyId: number;
    tenantCognitoId: string;
    name: string;
    email: string;
    phoneNumber: string;
    message: string;
  },
  property: { pricePerMonth: number; securityDeposit: number }
): Promise<
  Application & { property: Property; tenant: Tenant; lease: Lease | null }
> => {
  return await prisma.$transaction(async (prisma) => {
    // Creating lease first
    const lease = await prisma.lease.create({
      data: {
        startDate: new Date(), // Today
        endDate: new Date(new Date().setFullYear(new Date().getFullYear() + 1)), // 1 year from today
        rent: property.pricePerMonth,
        deposit: property.securityDeposit,
        property: {
          connect: { id: applicationData.propertyId },
        },
        tenant: {
          connect: { cognitoId: applicationData.tenantCognitoId },
        },
      },
    });

    // Then creating application with lease connection
    const application = await prisma.application.create({
      data: {
        applicationDate: new Date(applicationData.applicationDate),
        status: applicationData.status,
        name: applicationData.name,
        email: applicationData.email,
        phoneNumber: applicationData.phoneNumber,
        message: applicationData.message,
        property: {
          connect: { id: applicationData.propertyId },
        },
        tenant: {
          connect: { cognitoId: applicationData.tenantCognitoId },
        },
        lease: {
          connect: { id: lease.id },
        },
      },
      include: {
        property: true,
        tenant: true,
        lease: true,
      },
    });

    return application;
  });
};

/**
 * Approves an application by creating a lease and updating property/application
 * @param {string} applicationId - Application ID to approve
 * @param {Application & { property: Property; tenant: Tenant; lease: Lease | null }} application - Application data with property details
 * @returns {Promise<Lease>} Created lease
 * @throws {Error} When approval process fails
 * @since 1.0.0
 */
export const approveApplication = async (
  applicationId: string,
  application: Application & {
    property: Property;
    tenant: Tenant;
    lease: Lease | null;
  }
): Promise<Lease> => {
  return await prisma.$transaction(async (prisma) => {
    // Creating lease
    const newLease = await prisma.lease.create({
      data: {
        startDate: new Date(),
        endDate: new Date(new Date().setFullYear(new Date().getFullYear() + 1)),
        rent: application.property.pricePerMonth,
        deposit: application.property.securityDeposit,
        propertyId: application.propertyId,
        tenantCognitoId: application.tenantCognitoId,
      },
    });

    // Updating the property to connect the tenant
    await prisma.property.update({
      where: { id: application.propertyId },
      data: {
        tenants: {
          connect: { cognitoId: application.tenantCognitoId },
        },
      },
    });

    // Updating the application with the new lease ID
    await prisma.application.update({
      where: { id: Number(applicationId) },
      data: { status: "Approved", leaseId: newLease.id },
    });

    return newLease;
  });
};

/**
 * Updates application status
 * @param {string} applicationId - Application ID to update
 * @param {ApplicationStatus} status - New status
 * @returns {Promise<Application & relations>} Updated application with related data
 * @throws {AppError} 500 when update fails
 * @since 1.0.0
 */
export const updateApplicationStatus = async (
  applicationId: string,
  status: ApplicationStatus
): Promise<
  | (Application & { property: Property; tenant: Tenant; lease: Lease | null })
  | null
> => {
  try {
    // Updating the application status
    await prisma.application.update({
      where: { id: Number(applicationId) },
      data: { status },
    });

    // Returning the updated application with all related data
    return await prisma.application.findUnique({
      where: { id: Number(applicationId) },
      include: {
        property: true,
        tenant: true,
        lease: true,
      },
    });
  } catch (error: any) {
    throw new AppError(
      `Failed to update application status: ${error.message}`,
      500
    );
  }
};
