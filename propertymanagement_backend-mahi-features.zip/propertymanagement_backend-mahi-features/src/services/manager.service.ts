import { PrismaClient } from "@prisma/client";
import { CreateManagerData, UpdateManagerData } from "../types/manager.types";
import { wktToGeoJSON } from "@terraformer/wkt";

const prisma = new PrismaClient();

/**
 * Finds a manager by their Cognito ID
 * @param {string} cognitoId - The Cognito ID of the manager
 * @returns {Promise<Manager | null>} The manager object or null if not found
 * @since 1.0.0
 */
export const findManagerById = (cognitoId: string) => {
  return prisma.manager.findUnique({ where: { cognitoId } });
};

/**
 * Updates a manager's information by their Cognito ID
 * @param {string} cognitoId - The Cognito ID of the manager to update
 * @param {UpdateManagerData} data - The data to update
 * @returns {Promise<Manager>} The updated manager object
 * @throws {Error} When manager is not found or update fails
 * @since 1.0.0
 */
export const updateManagerById = (
  cognitoId: string,
  data: UpdateManagerData
) => {
  return prisma.manager.update({
    where: { cognitoId },
    data,
  });
};

/**
 * Creates a new manager in the database
 * @param {CreateManagerData} data - The manager data to create
 * @returns {Promise<Manager>} The created manager object
 * @throws {Error} When creation fails or unique constraint is violated
 * @since 1.0.0
 */
export const createManager = (data: CreateManagerData) => {
  return prisma.manager.create({ data });
};

/**
 * Retrieves all properties managed by a specific manager with formatted location data
 * @param {string} cognitoId - The Cognito ID of the manager
 * @returns {Promise<any[]>} Array of properties with formatted coordinates
 * @throws {Error} When database query fails
 * @since 1.0.0
 */
export const getManagerProperties = async (cognitoId: string) => {
  const properties = await prisma.property.findMany({
    where: { managerCognitoId: cognitoId },
    include: {
      location: true,
    },
  });

  const propertiesWithFormattedLocation = await Promise.all(
    properties.map(async (property) => {
      const coordinates: { coordinates: string }[] =
        await prisma.$queryRaw`SELECT ST_asText(coordinates) as coordinates from "Location" where id = ${property.location.id}`;

      const geoJSON: any = wktToGeoJSON(coordinates[0]?.coordinates || "");
      const longitude = geoJSON.coordinates[0];
      const latitude = geoJSON.coordinates[1];

      return {
        ...property,
        location: {
          ...property.location,
          coordinates: {
            longitude,
            latitude,
          },
        },
      };
    })
  );

  return propertiesWithFormattedLocation;
};
