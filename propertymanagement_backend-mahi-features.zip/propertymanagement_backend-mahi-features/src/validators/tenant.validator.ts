import { z } from "zod";

/**
 * Validation schema for updating an existing tenant's information.
 * All fields are optional to support partial updates.
 * @type {z.ZodObject}
 * @since 1.0.0
 */
export const updateTenantSchema = z
  .object({
    name: z
      .string()
      .min(2, "Name must be at least 2 characters long")
      .optional(),
    email: z.email("Invalid email address").optional(),
    phoneNumber: z
      .string()
      .regex(/^\+[1-9]\d{1,14}$/, "Invalid phone number format")
      .optional(),
  })
  .strict();

/**
 * Validation schema for creating a new tenant.
 * Cognito ID, name, and email are required fields.
 * @type {z.ZodObject}
 * @since 1.0.0
 */
export const createTenantSchema = z
  .object({
    cognitoId: z.string().min(1, "Cognito ID is required"),
    name: z.string().min(2, "Name must be at least 2 characters long"),
    email: z.string().email("Invalid email address"),
    phoneNumber: z
      .string()
      .regex(/^\+[1-9]\d{1,14}$/, "Invalid phone number format")
      .optional(),
  })
  .strict();
