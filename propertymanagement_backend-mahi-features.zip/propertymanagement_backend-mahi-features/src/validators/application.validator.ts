import { z } from "zod";

/**
 * Schema for validating application creation data
 * @since 1.0.0
 */
export const createApplicationSchema = z
  .object({
    applicationDate: z
      .string()
      .min(1, "Application date is required")
      .refine(
        (date) => !isNaN(Date.parse(date)),
        "Application date must be a valid date"
      ),
    status: z.enum(["Pending", "Approved", "Denied"], {
      message: "Status must be one of: Pending, Approved, Denied",
    }),
    propertyId: z
      .number()
      .positive("Property ID must be a positive number")
      .int("Property ID must be an integer"),
    tenantCognitoId: z
      .string()
      .min(1, "Tenant Cognito ID is required")
      .max(255, "Tenant Cognito ID is too long"),
    name: z
      .string()
      .min(1, "Applicant name is required")
      .max(255, "Applicant name is too long")
      .regex(
        /^[a-zA-Z\s'-]+$/,
        "Name can only contain letters, spaces, hyphens, and apostrophes"
      ),
    email: z
      .string()
      .min(1, "Email is required")
      .email("Email must be a valid email address")
      .max(255, "Email is too long"),
    phoneNumber: z
      .string()
      .min(1, "Phone number is required")
      .regex(/^[\+]?[1-9][\d]{0,15}$/, "Phone number must be a valid format")
      .max(20, "Phone number is too long"),
    message: z
      .string()
      .max(1000, "Message cannot exceed 1000 characters")
      .optional(),
  })
  .strict();

/**
 * Schema for validating application status update
 * @since 1.0.0
 */
export const updateApplicationStatusSchema = z
  .object({
    status: z.enum(["Pending", "Approved", "Denied"], {
      message: "Status must be one of: Pending, Approved, Denied",
    }),
  })
  .strict();

/**
 * Schema for validating application query parameters
 * @since 1.0.0
 */
export const applicationQuerySchema = z
  .object({
    userId: z.string().min(1, "User ID is required").optional(),
    userType: z.enum(["tenant", "manager"], {
      message: "User type must be either 'tenant' or 'manager'",
    }),
  })
  .strict();

/**
 * Type definitions for application validation schemas
 */
export type CreateApplicationData = z.infer<typeof createApplicationSchema>;
export type UpdateApplicationStatusData = z.infer<
  typeof updateApplicationStatusSchema
>;
export type ApplicationQueryData = z.infer<typeof applicationQuerySchema>;
