import { z } from "zod";
import { Request, Response, NextFunction } from "express";
import { AppError } from "../middleware/errorHandler";

/**
 * Validation schema for Cognito ID parameters in request URLs.
 * Ensures the Cognito ID follows the correct UUID format.
 * @type {z.ZodObject}
 * @since 1.0.0
 */
export const cognitoIdParamSchema = z.object({
  cognitoId: z
    .string()
    .regex(
      /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/,
      "Invalid Cognito ID format"
    ),
});

/**
 * Schema for validating unique ID parameter
 * Ensures the ID is a valid positive integer
 * @since 1.0.0
 */
export const uniqueIdSchema = z.object({
  id: z
    .string()
    .min(1, "Unique ID is required")
    .regex(/^\d+$/, "Unique ID must be a valid number")
    .transform((val) => parseInt(val, 10))
    .refine((val) => val > 0, "Unique ID must be a positive integer"),
});
