import { z } from "zod";

/**
 * Schema for validating property creation data
 * @since 1.0.0
 */
export const createPropertySchema = z
  .object({
    name: z
      .string()
      .min(1, "Property name is required")
      .max(255, "Property name is too long"),
    description: z
      .string()
      .min(1, "Description is required")
      .max(1000, "Description is too long"),
    pricePerMonth: z
      .string()
      .regex(/^\d+(\.\d{1,2})?$/, "Price must be a valid decimal number"),
    securityDeposit: z
      .string()
      .regex(
        /^\d+(\.\d{1,2})?$/,
        "Security deposit must be a valid decimal number"
      ),
    applicationFee: z
      .string()
      .regex(
        /^\d+(\.\d{1,2})?$/,
        "Application fee must be a valid decimal number"
      ),
    beds: z.string().regex(/^\d+$/, "Beds must be a valid number"),
    baths: z.string().regex(/^\d+(\.\d)?$/, "Baths must be a valid number"),
    squareFeet: z.string().regex(/^\d+$/, "Square feet must be a valid number"),
    propertyType: z.enum(
      ["Rooms", "Tinyhouse", "Apartment", "Villa", "Townhouse", "Cottage"],
      {
        message:
          "Property type must be one of: Rooms, Tinyhouse, Apartment, Villa, Townhouse, Cottage",
      }
    ),
    amenities: z.string().optional(),
    highlights: z.string().optional(),
    isPetsAllowed: z.enum(["true", "false"], {
      message: "Pets allowed must be true or false",
    }),
    isParkingIncluded: z.enum(["true", "false"], {
      message: "Parking included must be true or false",
    }),
    address: z
      .string()
      .min(1, "Address is required")
      .max(255, "Address is too long"),
    city: z
      .string()
      .min(1, "City is required")
      .max(100, "City name is too long"),
    state: z
      .string()
      .min(1, "State is required")
      .max(100, "State name is too long"),
    country: z
      .string()
      .min(1, "Country is required")
      .max(100, "Country name is too long"),
    postalCode: z
      .string()
      .min(1, "Postal code is required")
      .max(20, "Postal code is too long"),
    managerCognitoId: z.string().min(1, "Manager ID is required"),
  })
  .strict();

/**
 * Schema for validating property search/filter parameters
 * @since 1.0.0
 */
export const propertyFilterSchema = z.object({
  favoriteIds: z.string().optional(),
  priceMin: z
    .string()
    .regex(/^\d+(\.\d{1,2})?$/, "Minimum price must be a valid number")
    .optional(),
  priceMax: z
    .string()
    .regex(/^\d+(\.\d{1,2})?$/, "Maximum price must be a valid number")
    .optional(),
  beds: z
    .union([
      z.literal("any"),
      z.string().regex(/^\d+$/, "Beds must be a valid number"),
    ])
    .optional(),
  baths: z
    .union([
      z.literal("any"),
      z.string().regex(/^\d+(\.\d)?$/, "Baths must be a valid number"),
    ])
    .optional(),
  propertyType: z
    .union([
      z.literal("any"),
      z.enum([
        "Rooms",
        "Tinyhouse",
        "Apartment",
        "Villa",
        "Townhouse",
        "Cottage",
      ]),
    ])
    .optional(),
  squareFeetMin: z
    .string()
    .regex(/^\d+$/, "Minimum square feet must be a valid number")
    .optional(),
  squareFeetMax: z
    .string()
    .regex(/^\d+$/, "Maximum square feet must be a valid number")
    .optional(),
  amenities: z.union([z.literal("any"), z.string()]).optional(),
  availableFrom: z.union([z.literal("any"), z.string().datetime()]).optional(),
  latitude: z
    .string()
    .regex(/^-?\d+(\.\d+)?$/, "Latitude must be a valid number")
    .optional(),
  longitude: z
    .string()
    .regex(/^-?\d+(\.\d+)?$/, "Longitude must be a valid number")
    .optional(),
});

/**
 * Type definitions for property validation schemas
 */
export type CreatePropertyData = z.infer<typeof createPropertySchema>;
export type PropertyFilterData = z.infer<typeof propertyFilterSchema>;
