import { Request, Response } from "express";
import { PrismaClient } from "@prisma/client";
import * as leaseService from "../services/lease.service";
import { AppError } from "../middleware/errorHandler";
import * as paymentService from "../services/payment.service";

const prisma = new PrismaClient();

export const getLeases = async (req: Request, res: Response): Promise<void> => {
  try {
    const leases = await leaseService.getLeases();
    res.json(leases);
  } catch (error: any) {
    throw new AppError(`Error retrieving leases: ${error.message}`, 500);
  }
};

export const getLeasePayments = async (
  req: Request,
  res: Response
): Promise<void> => {
  try {
    const { leaseId } = req.params;
    const lease = await leaseService.findLeaseById(leaseId);
    if (!lease) {
      throw new AppError("Lease not found", 404);
    }
    // Fetching payments related to the lease
    const payments = await paymentService.getPaymentsByLeaseId(leaseId);
    res.json(payments);
  } catch (error: any) {
    throw new AppError(`Error retrieving payments: ${error.message}`, 500);
  }
};
