import { Request, Response, NextFunction } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { PrismaClient } from "@prisma/client";
import { AppError } from "../middleware/errorHandler";

const prisma = new PrismaClient();
const JWT_SECRET = process.env.JWT_SECRET!;
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || "7d";

export const register = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { email, password, role, name, phoneNumber } = req.body;

    if (!email || !password || !role || !name) {
      throw new AppError("email, password, role, and name are required", 400);
    }

    const validRoles = ["tenant", "manager"];
    if (!validRoles.includes(role.toLowerCase())) {
      throw new AppError("Role must be tenant or manager", 400);
    }

    const existing = await prisma.user.findUnique({ where: { email } });
    if (existing) {
      throw new AppError("An account with this email already exists", 409);
    }

    const passwordHash = await bcrypt.hash(password, 12);

    const user = await prisma.user.create({
      data: { email, passwordHash, role: role.toLowerCase() },
    });

    if (role.toLowerCase() === "manager") {
      await prisma.manager.create({
        data: {
          cognitoId: user.id,
          name,
          email,
          phoneNumber: phoneNumber || "",
        },
      });
    } else {
      await prisma.tenant.create({
        data: {
          cognitoId: user.id,
          name,
          email,
          phoneNumber: phoneNumber || "",
        },
      });
    }

    const token = jwt.sign(
      { sub: user.id, role: user.role, email: user.email },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN } as any
    );

    res.status(201).json({ token, role: user.role, userId: user.id });
  } catch (error) {
    next(error);
  }
};

export const login = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      throw new AppError("email and password are required", 400);
    }

    const user = await prisma.user.findUnique({ where: { email } });
    if (!user) {
      throw new AppError("Invalid credentials", 401);
    }

    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) {
      throw new AppError("Invalid credentials", 401);
    }

    const token = jwt.sign(
      { sub: user.id, role: user.role, email: user.email },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN } as any
    );

    res.json({ token, role: user.role, userId: user.id });
  } catch (error) {
    next(error);
  }
};

export const getMe = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const userId = req.user?.id;
    const userRole = req.user?.role;

    if (!userId || !userRole) {
      throw new AppError("Unauthorized", 401);
    }

    let profile;
    if (userRole === "manager") {
      profile = await prisma.manager.findUnique({ where: { cognitoId: userId } });
    } else {
      profile = await prisma.tenant.findUnique({
        where: { cognitoId: userId },
        include: { favorites: true },
      });
    }

    if (!profile) {
      throw new AppError("Profile not found", 404);
    }

    res.json({ userInfo: profile, userRole, userId });
  } catch (error) {
    next(error);
  }
};
