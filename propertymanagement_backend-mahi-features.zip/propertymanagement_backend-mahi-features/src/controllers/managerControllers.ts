import { Request, Response, NextFunction } from "express";
import { AppError } from "../middleware/errorHandler";
import * as managerService from "../services/manager.service";
import { Prisma, PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

/**
 * Retrieves a manager by their Cognito ID.
 * If the manager profile does not exist yet (e.g. migrated from old auth),
 * it is auto-created from the User record on first fetch.
 */
export const getManager = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { cognitoId } = req.params;
    let manager = await managerService.findManagerById(cognitoId);

    if (!manager) {
      // Auto-create profile from User row if it exists
      const user = await prisma.user.findUnique({ where: { id: cognitoId } });
      if (!user) throw new AppError("Manager not found", 404);

      manager = await prisma.manager.create({
        data: {
          cognitoId: user.id,
          name: user.email.split("@")[0], // sensible default until user updates settings
          email: user.email,
          phoneNumber: "",
        },
      });
    }

    res.json(manager);
  } catch (error) {
    next(error);
  }
};

/**
 * Creates a new manager in the system
 * @param {Request} req - Express request object containing manager data in body
 * @param {Response} res - Express response object
 * @param {NextFunction} next - Express next function for error handling
 * @throws {AppError} 409 when email or other unique field is already in use
 * @since 1.0.0
 */
export const createManager = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const { cognitoId, name, email, phoneNumber } = req.body;
  try {
    const manager = await managerService.createManager({
      cognitoId,
      name,
      email,
      phoneNumber,
    });
    res.status(201).json(manager);
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      if (error.code === "P2002") {
        const field = (error.meta?.target as string[])?.[0] || "field";
        throw new AppError(`This ${field} is already in use.`, 409);
      }
    }
    next(error);
  }
};

/**
 * Updates an existing manager's information
 * @param {Request} req - Express request object containing cognitoId in params and update data in body
 * @param {Response} res - Express response object
 * @param {NextFunction} next - Express next function for error handling
 * @throws {AppError} 404 when manager is not found
 * @throws {AppError} 403 when user tries to update another user's profile
 * @throws {AppError} 409 when email or other unique field is already in use
 * @since 1.0.0
 */
export const updateManager = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const { cognitoId } = req?.params;

  const manager = await managerService.findManagerById(cognitoId);
  if (!manager) {
    throw new AppError("Manager not found", 404);
  }

  // Authorization check: Ensuring the user can only update their own profile
  const currentUserCognitoId = req.user?.id;
  if (currentUserCognitoId !== cognitoId) {
    throw new AppError("Forbidden: You can only update your own profile.", 403);
  }

  try {
    const updatedManager = await managerService.updateManagerById(
      cognitoId,
      req.body
    );
    res.status(200).json(updatedManager);
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      if (error.code === "P2002") {
        const field = (error.meta?.target as string[])?.[0] || "field";
        throw new AppError(`This ${field} is already in use.`, 409);
      }
    }
    next(error);
  }
};

/**
 * Retrieves all properties managed by a specific manager
 * @param {Request} req - Express request object containing cognitoId in params
 * @param {Response} res - Express response object
 * @param {NextFunction} next - Express next function for error handling
 * @throws {AppError} 500 when service operation fails
 * @since 1.0.0
 */
export const getManagerProperties = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { cognitoId } = req.params;
    const properties = await managerService.getManagerProperties(cognitoId);
    res.json(properties);
  } catch (error) {
    next(error);
  }
};
