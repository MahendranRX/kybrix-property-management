import { Request, Response } from "express";
import * as propertyService from "../services/property.service";
import { AppError } from "../middleware/errorHandler";
import { PrismaClient, Prisma } from "@prisma/client";
import { wktToGeoJSON } from "@terraformer/wkt";
import { S3Client } from "@aws-sdk/client-s3";
import { Location } from "@prisma/client";
import { Upload } from "@aws-sdk/lib-storage";
import axios from "axios";
import * as leaseService from "../services/lease.service";
import { getLeasesByPropertyId } from "./../services/lease.service";

const prisma = new PrismaClient();

const s3Client = new S3Client({
  region: process.env.AWS_REGION,
});

export const getProperties = async (
  req: Request,
  res: Response
): Promise<void> => {
  try {
    // Extract query params
    const {
      favoriteIds,
      priceMin,
      priceMax,
      beds,
      baths,
      propertyType,
      squareFeetMin,
      squareFeetMax,
      amenities,
      availableFrom,
      latitude,
      longitude,
    } = req.query;

    // Call service
    const properties = await propertyService.getProperties({
      favoriteIds,
      priceMin,
      priceMax,
      beds,
      baths,
      propertyType,
      squareFeetMin,
      squareFeetMax,
      amenities,
      availableFrom,
      latitude,
      longitude,
    });
    res.json(properties);
  } catch (error: any) {
    throw new AppError(`Failed to get properties: ${error.message}`, 500);
  }
};

export const getProperty = async (
  req: Request,
  res: Response
): Promise<void> => {
  try {
    const { propertyId } = req.params;

    if (!propertyId) {
      throw new AppError("Property ID is required", 400);
    }

    const id = Number(propertyId);

    if (isNaN(id)) {
      throw new AppError("Invalid property ID", 400);
    }

    const property = await propertyService.findPropertyById(id);

    if (!property) {
      throw new AppError("Property not found", 404);
    }

    const propertyWithCoordinates =
      await propertyService.getPropertyWithCoordinates(property);
    res.json(propertyWithCoordinates);
  } catch (error: any) {
    throw new AppError(`Failed to get property: ${error.message}`, 500);
  }
};

export const createProperty = async (
  req: Request,
  res: Response
): Promise<void> => {
  try {
    const files = req.files as Express.Multer.File[];
    const {
      address,
      city,
      state,
      country,
      postalCode,
      managerCognitoId,
      ...propertyData
    } = req.body;

    // const photoUrls = await propertyService.getPhotoUrls(files);

    // create location
    const location = await propertyService.createLocation({
      address,
      city,
      state,
      country,
      postalCode,
    });

    // create property
    const newProperty = await propertyService.createProperty(
      propertyData,
      location.id,
      managerCognitoId
    );

    res.status(201).json(newProperty);
  } catch (err: any) {
    throw new AppError(`Failed to create property: ${err.message}`, 500);
  }
};

export const getLeases = async (req: Request, res: Response): Promise<void> => {
  try {
    const { propertyId } = req.params;

    if (!propertyId) {
      throw new AppError("Property Not Found", 404);
    }

    const leases = await leaseService.getLeasesByPropertyId(Number(propertyId));

    if (!leases) {
      throw new AppError("No Leases found for this property", 404);
    }

    res.status(200).json(leases);
  } catch (err: any) {
    throw new AppError(`Failed to create lease: ${err.message}`, 500);
  }
};
