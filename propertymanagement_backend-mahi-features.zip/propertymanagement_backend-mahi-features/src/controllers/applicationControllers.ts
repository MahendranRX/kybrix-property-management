import { Request, Response } from "express";
import { PrismaClient } from "@prisma/client";
import * as applicationService from "../services/application.service";

const prisma = new PrismaClient();
import * as propertyService from "../services/property.service";
import { AppError } from "../middleware/errorHandler";

export const listApplications = async (
  req: Request,
  res: Response
): Promise<void> => {
  try {
    const { userId, userType } = req.query;

    let whereClause = applicationService.determineWhereClause(
      String(userId),
      String(userType)
    );

    const applications = await applicationService.findApplications(whereClause);

    const formattedApplications = await applicationService.formatApplications(
      applications
    );

    res.json(formattedApplications);
  } catch (error: any) {
    throw new Error(`Failed to list applications: ${error.message}`);
  }
};

export const createApplication = async (
  req: Request,
  res: Response
): Promise<void> => {
  try {
    const {
      applicationDate,
      status,
      propertyId,
      tenantCognitoId,
      name,
      email,
      phoneNumber,
      message,
    } = req.body;

    const property = await propertyService.getPropertyPriceAndDeposit(
      propertyId
    );

    if (!property) {
      throw new AppError(`Property not found`, 404);
    }

    const newApplication = await applicationService.createApplicationWithLease(
      {
        applicationDate,
        status,
        propertyId,
        tenantCognitoId,
        name,
        email,
        phoneNumber,
        message,
      },
      property
    );

    res.status(201).json(newApplication);
  } catch (error: any) {
    throw new AppError(`Failed to create application: ${error.message}`, 500);
  }
};

export const updateApplicationStatus = async (
  req: Request,
  res: Response
): Promise<void> => {
  try {
    const { applicationId } = req.params;
    const { status } = req.body;

    const application = await applicationService.findApplicationById(
      applicationId
    );

    if (!application) {
      throw new AppError(`Application not found`, 404);
    }

    if (status === "Approved") {
      await applicationService.approveApplication(applicationId, application);
    } else {
      // Updating the application status (for both "Denied" and other statuses)
      await applicationService.updateApplicationStatus(applicationId, status);
    }

    // Responding with the updated application details
    const updatedApplication = await applicationService.findApplicationById(
      applicationId
    );

    res.json(updatedApplication);
  } catch (error: any) {
    res
      .status(500)
      .json({ message: `Error updating application status: ${error.message}` });
  }
};
