import { Request, Response, NextFunction } from "express";
import { Prisma, PrismaClient } from "@prisma/client";
import { AppError } from "../middleware/errorHandler";
import * as tenantService from "../services/tenant.service";

const prisma = new PrismaClient();

/**
 * Retrieves a tenant by their Cognito ID.
 * If the tenant profile does not exist yet (e.g. migrated from old auth),
 * it is auto-created from the User record on first fetch.
 */
export const getTenant = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { cognitoId } = req?.params;
    let tenant = await tenantService.findTenantWithFavorites(cognitoId);

    if (!tenant) {
      // Auto-create profile from User row if it exists
      const user = await prisma.user.findUnique({ where: { id: cognitoId } });
      if (!user) throw new AppError("Tenant not found", 404);

      tenant = await prisma.tenant.create({
        data: {
          cognitoId: user.id,
          name: user.email.split("@")[0], // sensible default until user updates settings
          email: user.email,
          phoneNumber: "",
        },
        include: { favorites: true },
      });
    }

    res.json(tenant);
  } catch (error) {
    next(error);
  }
};

/**
 * Creates a new tenant in the system
 * @param {Request} req - Express request object containing tenant data in body
 * @param {Response} res - Express response object
 * @param {NextFunction} next - Express next function for error handling
 * @throws {AppError} 409 when email or other unique field is already in use
 * @since 1.0.0
 */
export const createTenant = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const { cognitoId, name, email, phoneNumber } = req?.body;
  try {
    const tenant = await tenantService.createTenant({
      cognitoId,
      name,
      email,
      phoneNumber,
    });
    res.status(201).json(tenant);
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      if (error.code === "P2002") {
        const field = (error.meta?.target as string[])?.[0] || "field";
        throw new AppError(`This ${field} is already in use.`, 409);
      }
    }
    next(error);
  }
};

/**
 * Updates an existing tenant's information
 * @param {Request} req - Express request object containing cognitoId in params and update data in body
 * @param {Response} res - Express response object
 * @param {NextFunction} next - Express next function for error handling
 * @throws {AppError} 404 when tenant is not found
 * @throws {AppError} 403 when user tries to update another user's profile
 * @throws {AppError} 409 when email or other unique field is already in use
 * @since 1.0.0
 */
export const updateTenant = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const { cognitoId } = req?.params;

  const tenant = tenantService.findTenantById(cognitoId);

  if (!tenant) {
    throw new AppError("tenant not found", 404);
  }

  // Authorization check: Ensuring the user can only update their own profile
  const currentUserCognitoId = req.user?.id;
  if (currentUserCognitoId !== cognitoId) {
    throw new AppError("Forbidden: You can only update your own profile.", 403);
  }

  try {
    const updatedTenant = await tenantService.updateTenantById(
      cognitoId,
      req.body
    );
    res.status(200).json(updatedTenant);
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      if (error.code === "P2002") {
        const field = (error.meta?.target as string[])?.[0] || "field";
        throw new AppError(`This ${field} is already in use.`, 409);
      }
    }
    next(error); // Passing unhandled errors to the error handler
  }
};

export const getCurrentResidences = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { cognitoId } = req.params;
    const residences = await tenantService.getCurrentResidences(cognitoId);
    res.json(residences);
  } catch (error) {
    next(error);
  }
};

export const addFavoriteProperty = async (
  req: Request,
  res: Response
): Promise<void> => {
  try {
    const { cognitoId, propertyId } = req.params;
    const tenant = await tenantService.findTenantWithFavorites(cognitoId);

    if (!tenant) {
      throw new AppError("tenant not found", 404);
    }

    const propertyIdNumber = Number(propertyId);
    const existingFavorites = tenant.favorites || [];

    if (!existingFavorites.some((fav) => fav.id === propertyIdNumber)) {
      const updatedTenant = await tenantService.addFavoriteProperty(
        cognitoId,
        propertyIdNumber
      );

      res.json(updatedTenant);
    } else {
      throw new AppError("Property already added as favorite", 409);
    }
  } catch (error: any) {
    throw new AppError(
      `Failed to add favorite property: ${error.message}`,
      500
    );
  }
};

export const removeFavoriteProperty = async (
  req: Request,
  res: Response
): Promise<void> => {
  try {
    const { cognitoId, propertyId } = req.params;
    const propertyIdNumber = Number(propertyId);

    const updatedTenant = await tenantService.removeFavoriteProperty(
      cognitoId,
      propertyIdNumber
    );

    res.json(updatedTenant);
  } catch (err: any) {
    throw new AppError(
      `Failed to remove favorite property: ${err.message}`,
      500
    );
  }
};
