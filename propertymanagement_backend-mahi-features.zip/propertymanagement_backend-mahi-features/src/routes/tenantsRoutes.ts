import { Router } from "express";

import {
  getTenant,
  createTenant,
  updateTenant,
  getCurrentResidences,
  addFavoriteProperty,
  removeFavoriteProperty,
} from "../controllers/tenantControllers";
import {
  validateData,
  validateCognitoIdParam,
  validateUniqueIdParam,
} from "../middleware/validationMiddleware";
import {
  createTenantSchema,
  updateTenantSchema,
} from "../validators/tenant.validator";

const router = Router();
router.get("/:cognitoId", validateCognitoIdParam, getTenant);
router.get(
  "/residences/:cognitoId",
  validateCognitoIdParam,
  getCurrentResidences
);
router.post("/", validateData(createTenantSchema), createTenant);
router.post(
  "/:cognitoId/favorites/:propertyId",
  [validateCognitoIdParam, validateUniqueIdParam],
  addFavoriteProperty
);
router.put(
  "/:cognitoId",
  [validateCognitoIdParam, validateData(updateTenantSchema)],
  updateTenant
);
router.delete(
  "/:cognitoId/favorites/:propertyId",
  [validateCognitoIdParam, validateUniqueIdParam],
  removeFavoriteProperty
);

export default router;
