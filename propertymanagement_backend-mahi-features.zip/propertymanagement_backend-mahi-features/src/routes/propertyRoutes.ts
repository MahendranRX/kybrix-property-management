import express from "express";
import {
  getProperties,
  getProperty,
  createProperty,
} from "../controllers/propertyControllers";
import multer from "multer";
import { authMiddleware } from "../middleware/authMiddleware";
import { validate } from "uuid";
import {
  validateData,
  validateQuery,
  validateUniqueIdParam,
} from "../middleware/validationMiddleware";
import {
  createPropertySchema,
  propertyFilterSchema,
} from "../validators/property.validator";

const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

const router = express.Router();

router.get(
  "/",
  validateQuery(propertyFilterSchema),
  getProperties
);
router.get("/:propertyId", getProperty);
router.post(
  "/",
  authMiddleware(["manager"]),
  upload.array("photos"),
  validateData(createPropertySchema),
  createProperty
);
router.get("/leases/:propertyId", [
  authMiddleware(["manager"]),
  validateUniqueIdParam,
]);

export default router;
