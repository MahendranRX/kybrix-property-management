import express from "express";
import {
  getManager,
  createManager,
  updateManager,
  getManagerProperties,
} from "../controllers/managerControllers";
import {
  validateCognitoIdParam,
  validateData,
} from "../middleware/validationMiddleware";
import {
  createManagerSchema,
  updateManagerSchema,
} from "../validators/manager.validator";

const router = express.Router();

router.get("/:cognitoId", validateCognitoIdParam, getManager);
router.get(
  "/properties/:cognitoId",
  validateCognitoIdParam,
  getManagerProperties
);
router.post("/", validateData(createManagerSchema), createManager);
router.put(
  "/:cognitoId",
  [validateCognitoIdParam, validateData(updateManagerSchema)],
  updateManager
);

export default router;
