import express from "express";
import { authMiddleware } from "../middleware/authMiddleware";
import {
  createApplication,
  listApplications,
  updateApplicationStatus,
} from "../controllers/applicationControllers";
import {
  validateData,
  validateQuery,
  validateUniqueIdParam,
} from "../middleware/validationMiddleware";
import {
  applicationQuerySchema,
  createApplicationSchema,
  updateApplicationStatusSchema,
} from "../validators/application.validator";

const router = express.Router();

router.post(
  "/",
  [authMiddleware(["tenant"]), validateData(createApplicationSchema)],
  createApplication
);
router.put(
  "/:applicationId/status",
  [
    authMiddleware(["manager"]),
    validateUniqueIdParam,
    validateData(updateApplicationStatusSchema),
  ],
  updateApplicationStatus
);
router.get(
  "/",
  [
    authMiddleware(["manager", "tenant"]),
    validateQuery(applicationQuerySchema),
  ],
  listApplications
);

export default router;
