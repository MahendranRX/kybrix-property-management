import express from "express";
import { authMiddleware } from "../middleware/authMiddleware";
import { getLeasePayments, getLeases } from "../controllers/leaseControllers";
import { validateUniqueIdParam } from "../middleware/validationMiddleware";

const router = express.Router();

router.get("/", [authMiddleware(["manager", "tenant"])], getLeases);
router.get(
  "/:leaseId/payments",
  [authMiddleware(["manager", "tenant"]), validateUniqueIdParam],
  getLeasePayments
);

export default router;
