export interface UpdateTenantData {
  name?: string;
  email?: string;
  phoneNumber?: string;
}

export interface CreateTenantData {
  cognitoId: string;
  name: string;
  email: string;
  phoneNumber: string;
}
