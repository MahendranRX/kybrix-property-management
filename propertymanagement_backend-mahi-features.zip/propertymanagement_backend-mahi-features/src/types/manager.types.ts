export interface UpdateManagerData {
  name?: string;
  email?: string;
  phoneNumber?: string;
}

export interface CreateManagerData {
  cognitoId: string;
  name: string;
  email: string;
  phoneNumber: string;
}
