"use client";

import React, { useEffect, useState } from "react";
import { usePathname, useRouter } from "next/navigation";

const Auth = ({ children }: { children: React.ReactNode }) => {
  const router = useRouter();
  const pathname = usePathname();
  const [checked, setChecked] = useState(false);

  const isAuthPage = pathname === "/signin" || pathname === "/signup";
  const isDashboardPage = pathname.startsWith("/managers") || pathname.startsWith("/tenants");

  useEffect(() => {
    // Never redirect away from auth pages — let the user sign in / sign up freely
    if (isAuthPage) {
      setChecked(true);
      return;
    }

    const token = localStorage.getItem("token");

    // Protect dashboard pages: if no token, kick to sign-in
    if (!token && isDashboardPage) {
      router.push("/signin");
    } else {
      setChecked(true);
    }
  }, [pathname]);

  if (!checked && isDashboardPage) return null;
  return <>{children}</>;
};

export default Auth;
