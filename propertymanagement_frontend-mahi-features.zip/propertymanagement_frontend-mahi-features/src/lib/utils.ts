import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { toast } from "sonner";

/**
 * Combines class names using clsx and tailwind-merge for optimal Tailwind CSS class handling
 * @param {...ClassValue[]} inputs - Class values to combine
 * @returns {string} Combined and optimized class string
 * @since 1.0.0
 *
 * @example
 * cn('px-4 py-2', 'bg-blue-500', { 'text-white': true })
 * // Returns: 'px-4 py-2 bg-blue-500 text-white'
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Formats enum strings by adding spaces before capital letters
 * @param {string} str - The enum string to format
 * @returns {string} Formatted string with spaces
 * @since 1.0.0
 *
 * @example
 * formatEnumString('WasherDryer') // Returns: 'Washer Dryer'
 */
export function formatEnumString(str: string) {
  return str.replace(/([A-Z])/g, " $1").trim();
}

/**
 * Formats price values for display with appropriate prefixes and suffixes
 * @param {number | null} value - The price value to format
 * @param {boolean} isMin - Whether this is a minimum price (affects prefix/suffix)
 * @returns {string} Formatted price string
 * @since 1.0.0
 *
 * @example
 * formatPriceValue(1500, true)  // Returns: '$1.5k+'
 * formatPriceValue(2000, false) // Returns: '<$2k'
 */
export function formatPriceValue(value: number | null, isMin: boolean) {
  if (value === null || value === 0)
    return isMin ? "Any Min Price" : "Any Max Price";
  if (value >= 1000) {
    const kValue = value / 1000;
    return isMin ? `$${kValue}k+` : `<$${kValue}k`;
  }
  return isMin ? `$${value}+` : `<$${value}`;
}

/**
 * Cleans parameter objects by removing undefined, null, empty, and "any" values
 * @param {Record<string, any>} params - The parameters object to clean
 * @returns {Record<string, any>} Cleaned parameters object with only valid values
 * @since 1.0.0
 *
 * @example
 * cleanParams({ name: 'John', age: null, city: '', type: 'any' })
 * // Returns: { name: 'John' }
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function cleanParams(params: Record<string, any>): Record<string, any> {
  return Object.fromEntries(
    Object.entries(params).filter(
      (
        [key, value] // eslint-disable-line @typescript-eslint/no-unused-vars
      ) => {
        if (value === undefined || value === "any" || value === "" || value === null)
          return false;
        // Treat [0, 0] coordinates as "not set" — don't send them as a filter
        if (key === "coordinates" && Array.isArray(value) && value[0] === 0 && value[1] === 0)
          return false;
        if (Array.isArray(value)) return value.some((v) => v !== null);
        return true;
      }
    )
  );
}

/**
 * Type definition for mutation message configuration
 * @typedef {Object} MutationMessages
 * @property {string} [success] - Optional success message to display
 * @property {string} error - Error message to display on failure
 */
type MutationMessages = {
  success?: string;
  error: string;
};

/**
 * Wraps async mutations with toast notifications for success/error states
 * @template T
 * @param {Promise<T>} mutationFn - The async function to execute
 * @param {Partial<MutationMessages>} messages - Configuration for success/error messages
 * @returns {Promise<T>} The result of the mutation function
 * @throws {Error} Re-throws the original error after displaying error toast
 * @since 1.0.0
 *
 * @example
 * await withToast(
 *   updateUser({ id: 1, name: 'John' }),
 *   { success: 'User updated!', error: 'Failed to update user' }
 * );
 */
export const withToast = async <T>(
  mutationFn: Promise<T>,
  messages: Partial<MutationMessages>
) => {
  const { success, error } = messages;

  try {
    const result = await mutationFn;
    if (success) toast.success(success);
    return result;
  } catch (err) {
    if (error) toast.error(error);
    throw err;
  }
};
