// utils/redirectToSignIn.ts
"use client"; // ensures this is client-side only

import { createRef } from "react";
import { AppRouterInstance } from "next/dist/shared/lib/app-router-context.shared-runtime";

// A small singleton to store the router instance
const routerRef = createRef<AppRouterInstance>();

export function setAppRouter(router: AppRouterInstance) {
  routerRef.current = router;
}

/**
 * Redirects to the signin page using Next.js App Router.
 * Can be called anywhere, even outside React hooks.
 */
export function redirectToSignIn() {
  if (routerRef.current) {
    routerRef.current.push("/signin");
  } else if (typeof window !== "undefined") {
    // fallback: using full reload if router not yet set
    window.location.href = "/signin";
  }
}
